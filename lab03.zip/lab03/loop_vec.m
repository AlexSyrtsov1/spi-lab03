clear
tic
n = 1:100000;
s = sum(1./n.^2);
toc
