clear
tic
s = 0;

for n = 1:100000
	s += 1/n^2;
end
toc
